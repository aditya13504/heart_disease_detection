import pandas as pd

# Load the dataset correctly (using semicolon as separator)
df = pd.read_csv("cardio_train.csv", sep=';')

# Display the first few rows
print(df.head())

# Optionally, save the clean version as a new CSV with proper columns
df.to_csv("cardio_train_clean.csv", index=False)